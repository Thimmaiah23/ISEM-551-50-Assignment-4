﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Web.Mvc;
using System.Web.Security;

namespace CCTV.Web.Models
{

    public class CameraCommandModel
    {
        [Required]
        public string CameraCommand { get; set; }

        [Required]
        public ushort CameraNumber { get; set; }

        [Required]
        public uint CameraSpeed { get; set; }
    }
}
