﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CCTV.Common;
using CCTV.Logic;
using CCTV.Web.Models;

namespace CCTV.Web.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            //CommandManager.WriteTestConfig();
            ViewBag.Message = "Welcome to ASP.NET MVC!";
            return View();
        }

        [CCTVAuthorize(AuthorizedRoles = new[] { SiteRoles.Admin, SiteRoles.User })]
        public ActionResult Test(string id)
        {
            CameraXML xml = CommandManager.GetConfig(); 

            ushort selectedCamera = xml.SelectedCamera;
            if (!string.IsNullOrEmpty(id) && ushort.TryParse(id, out selectedCamera))
            {
                //we have the correct cam...
                xml.SelectedCamera = selectedCamera;
            }
            return View("VideoControl", xml);
        }

        [CCTVAuthorize(AuthorizedRoles = new[] { SiteRoles.Admin, SiteRoles.User })]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult GetUserControlForCam(CCTVCamera cam)
        {
            CCTVCamera selectedCam = CommandManager.GetCameraFromId(cam.CameraNumber);
            CommandManager.GetConfig().SelectedCamera = selectedCam.CameraNumber;
            //change the active camera
            CommandManager.SwitchToCamera(selectedCam.CameraNumber);
            var cameraType = "_"+CommandManager.GetCameraFromId(cam.CameraNumber).CameraType.ToString() + "UserControl";
            return PartialView(cameraType, selectedCam);
        }

        [CCTVAuthorize(AuthorizedRoles = new[] { SiteRoles.Admin, SiteRoles.User })]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult PassCameraCommand(CameraCommandModel cmd)
        {
            CommandManager.InterpretCameraCommand(cmd.CameraNumber, cmd.CameraCommand, cmd.CameraSpeed);
            return GetEmptyResponse();
        }
       
        #region video related

        [CCTVAuthorize(AuthorizedRoles = new[] { SiteRoles.Admin, SiteRoles.User })]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult GetImage()
        {
            Response.Expires = 0;
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            byte[] f = CommandManager.GetPicture();
            if (f == null)
            {
                //return camera not available...
                return File(Url.Content("~/Content/images/placeholder.jpg"), "image/jpeg");
            }
            return File(f, "image/jpeg");
        }

        [CCTVAuthorize(AuthorizedRoles = new[] { SiteRoles.Admin, SiteRoles.User })]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult ChangeCompression(string id)
        {
            CommandManager.ChangeVideoCompression(id);
            return GetEmptyResponse();
        }

        [CCTVAuthorize(AuthorizedRoles = new[] { SiteRoles.Admin, SiteRoles.User })]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult ChangeSize(string id)
        {
            CommandManager.ChangeVideoSize(id);
            return GetEmptyResponse();
        }

        [CCTVAuthorize(AuthorizedRoles = new[] { SiteRoles.Admin, SiteRoles.User })]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult VideoCommand(string id)
        {
            CommandManager.VideoCommand(id);
            return GetEmptyResponse();
        }
        #endregion

        #region administration
        [CCTVAuthorize(AuthorizedRoles = new[] { SiteRoles.Admin })]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult AddUser(string id)
        {
            CommandManager.AddApplicationUser(id, Guid.NewGuid().ToString());
            return GetEmptyResponse();
        }

        [CCTVAuthorize(AuthorizedRoles = new[] { SiteRoles.Admin})]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult DeleteUser(string id)
        {
            CommandManager.DeleteApplicationUser(id);
            return GetEmptyResponse();
        }

        [CCTVAuthorize(AuthorizedRoles = new[] { SiteRoles.Admin})]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult ListUsers()
        {
            Response.Expires = 0;
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            return PartialView("_UserGrid", CommandManager.GetApplicationUsers());
        }

        [CCTVAuthorize(AuthorizedRoles = new[] { SiteRoles.Admin })]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult PassMainCommand(string id)
        {
            CommandManager.InterpretAdminCommand(id);
            return GetEmptyResponse();
        }
        #endregion

        private ActionResult GetEmptyResponse()
        {
            return Json( null, JsonRequestBehavior.AllowGet );
        }

        public ActionResult About()
        {
            return View();
        }
    }
}
