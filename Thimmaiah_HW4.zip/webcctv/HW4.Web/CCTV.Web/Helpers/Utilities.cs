﻿using CCTV.Common;
namespace CCTV.Web
{
    public static class Utilities
    {
        public static string GetJSFunction(string command)
        {
            return string.Format("callServerButton('{0}')", command);
        }

        public static string GetVideoStateFunction(AppConstants.VideoCommandsEnum cmd)
        {
            return string.Format("callServerVideoCommand('{0}')", cmd.ToString());
        }

        public static string GetVideoSizeJSFunction(AppConstants.VideoSizeEnum size)
        {
            return string.Format("callServerVideoSize('{0}')", size.ToString());
        }

        public static string GetVideoCompressionJSFunction(AppConstants.VideoCompressionEnum compression)
        {
            return string.Format("callServerVideoCompression('{0}')", compression.ToString());
        }

        public static string GetButtonCSS()
        {
            return "fixedbutton";
        }

    }
}