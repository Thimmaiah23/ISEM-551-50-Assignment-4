﻿
using System.Web.Mvc;
namespace System.Web.Mvc
{

    public static class Extenders
    {
        public static MvcHtmlString MouseDownButton(this HtmlHelper helper, string id, string label, string onButtonDownJS, string onButtonUpJS, string cssClass)
        {
            TagBuilder tb = new TagBuilder("input");
            tb.GenerateId(id);
            tb.MergeAttribute("value", label);
            tb.MergeAttribute("type", "button");
            if(!string.IsNullOrEmpty(onButtonDownJS))
                tb.MergeAttribute("onmousedown", onButtonDownJS);
            if(!string.IsNullOrEmpty(onButtonUpJS))
                tb.MergeAttribute("onmouseup", onButtonUpJS);
            if (!string.IsNullOrEmpty(cssClass))
                tb.MergeAttribute("class", cssClass);
            return new MvcHtmlString(tb.ToString());
        }

        public static MvcHtmlString NormalButton(this HtmlHelper helper, string id, string label, string onClick, string cssClass)
        {
            return MouseDownButton(helper, id, label, onClick, string.Empty, cssClass);
        }
    }
}