﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;
using System.Diagnostics;
using CCTV.Common;
using CCTV.Protocols;

namespace CCTV.SerialPorts
{
    public sealed class TandbergViscaPortManager : ICameraSerialPort
    {
        static TandbergVisca tdgProtocol = new TandbergVisca();

        static readonly TandbergViscaPortManager _instance = new TandbergViscaPortManager();

        public static TandbergViscaPortManager Instance
        {
            get
            {
                return _instance;
            }
        }

        private TandbergViscaPortManager()
        {
            
        }

        #region public
        public AppConstants.CommandType GetCommandType()
        {
            return AppConstants.CommandType.TandbergVisca;
        }

        public List<string> GetAvailableCommands()
        {
            List<string> cmds = new List<string>();
            foreach(AppConstants.TandbergViscaCommandsEnum cmd in Enum.GetValues(typeof(AppConstants.TandbergViscaCommandsEnum)))
            {
                cmds.Add(cmd.ToString());
            }
            return cmds;
        }
        
        public void SendCommand(string issuedCommand, uint cameraId, uint cSpeed, SerialPortBase serialPortToUse)
        {
            AppConstants.TandbergViscaCommandsEnum command = (AppConstants.TandbergViscaCommandsEnum)Enum.Parse(typeof(AppConstants.TandbergViscaCommandsEnum), issuedCommand);
            byte cameraSpeed = (byte)(0 + cSpeed);
            byte[] cmd = null;

            switch (command)
            {
                case AppConstants.TandbergViscaCommandsEnum.MoveUp:
                    cmd = tdgProtocol.CameraTilt(cameraId, TandbergVisca.Tilt.Up, cameraSpeed);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.MoveDown:
                    cmd = tdgProtocol.CameraTilt(cameraId, TandbergVisca.Tilt.Down, cameraSpeed);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.MoveLeft:
                    cmd = tdgProtocol.CameraPan(cameraId, TandbergVisca.Pan.Left, cameraSpeed);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.MoveRight:
                    cmd = tdgProtocol.CameraPan(cameraId, TandbergVisca.Pan.Right, cameraSpeed);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.MovementStop:
                    cmd = tdgProtocol.CameraStopMoving(cameraId);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.ZoomTele:
                    cmd = tdgProtocol.CameraZoom(cameraId, TandbergVisca.Zoom.Tele, cameraSpeed);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.ZoomWide:
                    cmd = tdgProtocol.CameraZoom(cameraId, TandbergVisca.Zoom.Wide, cameraSpeed);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.ZoomStop:
                    cmd = tdgProtocol.CameraZoom(cameraId, TandbergVisca.Zoom.Stop, cameraSpeed);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.FocusNear:
                    cmd = tdgProtocol.CameraFocus(cameraId, TandbergVisca.Focus.Near);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.FocusFar:
                    cmd = tdgProtocol.CameraFocus(cameraId, TandbergVisca.Focus.Far);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.FocusStop:
                    cmd = tdgProtocol.CameraFocus(cameraId, TandbergVisca.Focus.Stop);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.IrisOpen:
                    cmd = tdgProtocol.CameraIrisSwitch(cameraId, TandbergVisca.Iris.Open);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.IrisClose:
                    cmd = tdgProtocol.CameraIrisSwitch(cameraId, TandbergVisca.Iris.Close);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.IrisReset:
                    cmd = tdgProtocol.AutoIris(cameraId);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.GetPreset:
                    cmd = tdgProtocol.Preset(cameraId, (byte)cSpeed, TandbergVisca.PresetAction.Goto);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.SetPreset:
                    //use speed as parameter...
                    cmd = tdgProtocol.Preset(cameraId, (byte)cSpeed, TandbergVisca.PresetAction.Set);
                    break;

                case AppConstants.TandbergViscaCommandsEnum.IROn:
                    cmd = tdgProtocol.InfraRed(cameraId, TandbergVisca.SwitchAction.On);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.IROff:
                    cmd = tdgProtocol.InfraRed(cameraId, TandbergVisca.SwitchAction.Off);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.BackLightOff:
                    cmd = tdgProtocol.BackLightCompensation(cameraId, TandbergVisca.SwitchAction.Off);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.BackLightOn:
                    cmd = tdgProtocol.BackLightCompensation(cameraId, TandbergVisca.SwitchAction.On);
                    break;

                case AppConstants.TandbergViscaCommandsEnum.AWBOn:
                    cmd = tdgProtocol.AutoWhiteBalance(cameraId, TandbergVisca.SwitchAction.On);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.AWBOff:
                    cmd = tdgProtocol.AutoWhiteBalance(cameraId, TandbergVisca.SwitchAction.Off);
                    break;

                case AppConstants.TandbergViscaCommandsEnum.Autofocus:
                    cmd = tdgProtocol.AutoFocus(cameraId, TandbergVisca.SwitchAction.On);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.ManualFocus:
                    cmd = tdgProtocol.AutoFocus(cameraId, TandbergVisca.SwitchAction.Off);
                    break;
                case AppConstants.TandbergViscaCommandsEnum.Home:
                    cmd = tdgProtocol.ZeroPanPosition(cameraId);
                    break;

                default:
                    break;

            }

            serialPortToUse.SendValue(cmd);
        }

        #endregion
    }

}

