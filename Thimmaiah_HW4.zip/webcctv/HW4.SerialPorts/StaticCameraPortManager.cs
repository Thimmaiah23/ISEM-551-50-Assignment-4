﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;
using System.Diagnostics;
using CCTV.Common;
using CCTV.Protocols;

namespace CCTV.SerialPorts
{
    public sealed class StaticCameraPortManager : ICameraSerialPort
    {
   
        static readonly StaticCameraPortManager _instance = new StaticCameraPortManager();

        public static StaticCameraPortManager Instance
        {
            get
            {
                return _instance;
            }
        }

        private StaticCameraPortManager()
        {

        }

        #region public
        public AppConstants.CommandType GetCommandType()
        {
            return AppConstants.CommandType.StaticCamera;
        }

        public List<string> GetAvailableCommands()
        {
            throw new ApplicationException("This camera has no commands available!");
        }

        public void SendCommand(string issuedCommand, uint cameraId, uint cSpeed, SerialPortBase serialPortToUse)
        {
            throw new ApplicationException("This camera does not accept any commands!");
        }


        #endregion
    }

}