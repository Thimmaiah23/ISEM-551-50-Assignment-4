﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CCTV.Common;

namespace CCTV.SerialPorts
{
    public static class SerialPortFactory
    {
        static List<ICameraSerialPort> protocols = null;

        public static ICameraSerialPort GetProtocolInterpreter(AppConstants.CommandType typeToGet)
        {
            if (protocols == null)
                Init();

            ICameraSerialPort registeredProtocol = protocols.Where(x=> x.GetCommandType() == typeToGet).FirstOrDefault();
            if(registeredProtocol == null)
            {
                throw new ApplicationException("OOOPS: protocol not registered "+typeToGet.ToString());
            }
            return registeredProtocol;
        }

        private static void Init()
        {
            protocols = new List<ICameraSerialPort>();
            protocols.Add(PelcoDPortManager.Instance);
            protocols.Add(TandbergViscaPortManager.Instance);
            protocols.Add(StaticCameraPortManager.Instance);
        }
    }
}
