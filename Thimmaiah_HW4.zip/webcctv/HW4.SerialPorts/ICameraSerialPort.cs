﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CCTV.Common;

namespace CCTV.SerialPorts
{
    public interface ICameraSerialPort
    {
        void SendCommand(string command, uint cameraId, uint cSpeed, SerialPortBase serialPortToUse);

          AppConstants.CommandType GetCommandType();

        List<string> GetAvailableCommands();
    }
}
