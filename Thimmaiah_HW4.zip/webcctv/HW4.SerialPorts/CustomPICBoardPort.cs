﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;
using CCTV.Common;
using System.Diagnostics;
using CCTV.Protocols;

namespace CCTV.SerialPorts
{
    //singleton...
    public sealed class CustomPICBoardPort
    {
        static UTF8Encoding enc = new UTF8Encoding();

        static readonly CustomPICBoardPort _instance = new CustomPICBoardPort();

        public static CustomPICBoardPort Instance
        {
            get { return _instance; }
        }

        public CustomPICBoardPort()
        {

        }

        #region public

        public void SendCommand(AppConstants.CustomPICBoardCommandsEnum command, object optional, SerialPortBase serialPortToUse)
        {
            
            byte[] cmd = null;
            switch (command)
            {
                case AppConstants.CustomPICBoardCommandsEnum.CamValue:
                    if (optional is string)
                        cmd = GetEncoded((string)optional);
                    break;
                case AppConstants.CustomPICBoardCommandsEnum.Off:
                    cmd = GetEncoded(CustomPICBoard.CamerasOff);
                    break;
                case AppConstants.CustomPICBoardCommandsEnum.On:
                    cmd = GetEncoded(CustomPICBoard.CamerasOn);
                    break;
                default:
                    break;
            }
            serialPortToUse.SendValue(cmd);
        }
        #endregion

        #region private

        private static byte[] GetEncoded(string command)
        {
            return enc.GetBytes(command);
        }


        #endregion
    }
}
