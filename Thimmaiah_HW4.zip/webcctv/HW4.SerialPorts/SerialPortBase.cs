﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;
using CCTV.Common;

namespace CCTV.SerialPorts
{
    public class SerialPortBase
    {
        protected SerialPort comPort;
        private bool isDebug = false;

        public void SendValue(byte[] cmdToSend)
        {
            if (isDebug)
                return;
            
            if (comPort != null && comPort.IsOpen && cmdToSend != null)
            {
                comPort.Write(cmdToSend, 0, cmdToSend.Length);
            }
        }

        public void Open()
        {
            if (isDebug)
                return;

            if (comPort != null && !comPort.IsOpen)
                comPort.Open();
        }

        public void Close()
        {
            if (isDebug)
                return;

            if (comPort != null && comPort.IsOpen)
                comPort.Close();

        }

        public void Init(string port, int baudRate, bool isDebug)
        {
            this.isDebug = isDebug;
            if (comPort == null)
            {
                comPort = new SerialPort(port);
                comPort.BaudRate = baudRate; 
            }
        }

        public string PortName
        {
            get
            {
                return comPort.PortName;
            }
        }
    }
}
