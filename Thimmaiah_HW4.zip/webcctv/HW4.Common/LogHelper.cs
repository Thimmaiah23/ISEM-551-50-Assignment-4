﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace CCTV.Common
{
    public static class LogHelper
    {
        static StreamWriter sr = null;
        private static void Init()
        {
            string path = System.Reflection.Assembly.GetEntryAssembly().Location;
            path = path.Substring(0, path.LastIndexOf("\\"));
            path = Path.Combine(path, @"log.txt");
            //if (!File.Exists(path))
            //    sr = File.CreateText(path);
            //else
            //    sr = File.AppendText(path);
            sr = File.AppendText(path);
        }
        public static void LogLine(string entry)
        {
            if (sr == null)
                Init();

            sr.WriteLine(entry);
            sr.Flush();
        }

        public static void Close()
        {
            sr.Close();
            sr.Dispose();
        }
    }
}
