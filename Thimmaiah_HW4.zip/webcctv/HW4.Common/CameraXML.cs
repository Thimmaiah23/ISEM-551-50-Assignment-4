﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;

namespace CCTV.Common
{

    [Serializable]
    public class CameraXML
    {
        public string HardwareInterfacePort { get; set; }
        public int HardwareInterfaceBaudRate { get; set; }

        public bool IsDebug { get; set; }

        public string CamerasRS232TurnOnCommand { get; set; }
        public string CamerasRS232TurnOffCommand { get; set; }

        public ushort SelectedCamera { get; set; }

        public List<ApplicationUser> Users { get; set; }

        public List<CCTVCamera> Cameras { get; set; }

        public List<Robot> Robots { get; set; }

        public PanoSettings PanoSetting { get; set; }

        public CameraXML()
        {
            Cameras = new List<CCTVCamera>();
            Robots = new List<Robot>();
        }

        public static CameraXML ReadFromFile(string filePath)
        {
            CameraXML cam = new CameraXML();
            XmlSerializer ser = new XmlSerializer(typeof(CameraXML));
            using (TextReader tr = new StreamReader(filePath))
            {
                cam = (CameraXML)ser.Deserialize(tr);
                tr.Close();
            }
            return cam;
        }

        public static void WriteToFile(string filePath, CameraXML objToSerialize)
        {
            XmlSerializer ser = new XmlSerializer(typeof(CameraXML));

            using (TextWriter tr = new StreamWriter(filePath))
            {
                ser.Serialize(tr, objToSerialize);
            }
        }

    }

   
    [Serializable]
    public class CCTVCamera
    {
        public string CameraName { get; set; }
        public string SerialPort4Control { get; set; }
        public bool IsCurrentlyInUse { get; set; }
        public UInt16 CameraNumber { get; set; }
        public string CameraVideoSwitchCommand { get; set; }
        public AppConstants.CommandType CameraType { get; set; }
        public int BaudRate { get; set; }
        public int MinMovementSpeed { get; set; }
        public int MaxMovementSpeed { get; set; }
        public int DefaultMovementSpeed { get; set; }
        public int IncrementStepMovementSpeed { get; set; }

        public List<CCTVPreset> PresetPositions { get; set; }


        public CCTVCamera()
        {
            CameraNumber = 256;
            PresetPositions = new List<CCTVPreset>();
        }

        public void AddPosition(int posNumber, string title)
        {
            PresetPositions.Add(new CCTVPreset(posNumber, title));
        }
    }

    [Serializable]
    public class CCTVPreset
    {
        public int Number { get; set; }
        public string Name { get; set; }

        public CCTVPreset()
        {
        }

        public CCTVPreset(int nb, string name)
        {
            this.Number = nb;
            this.Name = name;
        }
    }

    [Serializable]
    public class ApplicationUser
    {
        [XmlAttribute]
        public string UserName { get; set; }
        [XmlAttribute]
        public string Password { get; set; }
        [XmlAttribute]
        public bool IsAdmin { get; set; }
        public DateTime? LastActivity { get; set; }
       

        public ApplicationUser()
        {
        }

        public ApplicationUser(string u, string p)
        {
            UserName = u;
            Password = p;
        }

    }

    [Serializable]
    public class ConnectedUserWrapper
    {
        [XmlAttribute]
        public ApplicationUser User { get; set; }
        [XmlAttribute]
        public string IP{ get; set; }
        [XmlAttribute]
        public bool JustConnected { get; set; }



        public ConnectedUserWrapper()
        {
        }

        public ConnectedUserWrapper(ApplicationUser u, string ip, bool justConnected)
        {
            User = u;
            IP = ip;
            JustConnected = justConnected;
        }

    }

    [Serializable]
    public class PanoSettings
    {
        [XmlAttribute]
        public string EmailTo { get; set; }        
        [XmlAttribute]
        public string EmailServer { get; set; }
        [XmlAttribute]
        public string EmailPassword { get; set; }
        [XmlAttribute]
        public string EmailUser { get; set; }

        [XmlAttribute]
        public int Interval { get; set; }
        [XmlAttribute]
        public bool SendAtInterval { get; set; }
        [XmlAttribute]
        public bool SendEmailAlso { get; set; }
        [XmlAttribute]
        public bool SendAtAlarm { get; set; }

        public List<PanoCameraSettings> Settings { get; set; }

        public PanoSettings()
        {
            Settings = new List<PanoCameraSettings>();
        }

    }

    [Serializable]
    public class PanoCameraSettings
    {
        [XmlAttribute]
        public uint CameraNumber { get; set;}
        
        public List<PanoPresetForStitch> PresetPositionNumbers {get; set;}
        
        public PanoCameraSettings()
        {
            CameraNumber = 256;
            PresetPositionNumbers = new List<PanoPresetForStitch>();
           
        }
    }

    [Serializable]
    public class PanoPresetForStitch
    {
        [XmlAttribute]
        public int Preset { get; set; }
        [XmlAttribute]
        public int OffsetXForStitching { get; set; }
        [XmlAttribute]
        public int OffsetYForStitching { get; set; }


        public PanoPresetForStitch()
        {
            Preset = -1;
            OffsetXForStitching = 0;
            OffsetYForStitching = 0;
        }
        public PanoPresetForStitch(int p, int x, int y)
        {
            Preset = p;
            OffsetXForStitching = x;
            OffsetYForStitching = y;
        }
    }

    [Serializable]
    public class Robot
    {
        public string RobotName { get; set; }
        public string PortName { get; set; }
        public List<RobotCommand> Commands { get; set; }

        public Robot()
        {
            Commands = new List<RobotCommand>();
        }

    }

    [Serializable]
    public class RobotCommand
    {
        public AppConstants.RobotCommandsEnum Name { get; set; }
        public string Value { get; set; }

        public RobotCommand()
        {
        }

        public RobotCommand(AppConstants.RobotCommandsEnum name, string val)
        {
            this.Name = name;
            this.Value = val;
        }
    }
}
