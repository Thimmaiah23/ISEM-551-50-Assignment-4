﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Mail;
using System.IO;

namespace CCTV.Common
{
    public static class MailHelper
    {

        public static void SendMail(
            string server, 
            int port,
            string user, string password,
            string senderEmail,
            string to,
            string subject,
            string message,
            List<string> attachments,
            string mimeType)
        {
            NetworkCredential loginInfo = new NetworkCredential(user, password);
            MailMessage msg = new MailMessage();
            msg.From = new MailAddress(senderEmail, "CCTV", Encoding.UTF8);
            string[] toAddresses = to.Split(new char[] { ',' });
            foreach (string s in toAddresses)
                msg.To.Add(new MailAddress(s));

            msg.Subject = subject;
            msg.SubjectEncoding = Encoding.UTF8;
            msg.Body = message;
            msg.BodyEncoding = Encoding.UTF8;
            msg.IsBodyHtml = true;
            msg.Priority = MailPriority.Normal;

            foreach (string attachment in attachments)
            {
                if (attachment != null)
                {
                    Attachment att = new Attachment(attachment, mimeType);
                    msg.Attachments.Add(att);
                }
            }

            SmtpClient client = new SmtpClient(server);
            //client.EnableSsl = true;
            client.UseDefaultCredentials = false;
            client.Credentials = loginInfo;
            client.Port = port;
            client.Send(msg);
            msg.Dispose();

           
        }

    }
}
