﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using System.Xml;

namespace CCTV.Common
{
    [Serializable]
    public class TCPPayload
    {
        
        public AppConstants.CustomPICBoardCommandsEnum CustomPICBoardCommand { get; set; }
        
        public AppConstants.PelcoDCommandsEnum PelcoDCommand { get; set; }

        public AppConstants.TandbergViscaCommandsEnum TandbergViscaCommand { get; set; }

        public CameraXML Cameras { get; set; }
        
        public uint OptionalCameraValue { get; set; }
        
        public uint OptionalValue {get; set;}


        public TCPPayload()
        {
            CustomPICBoardCommand = AppConstants.CustomPICBoardCommandsEnum.Undefined;
            PelcoDCommand = AppConstants.PelcoDCommandsEnum.Undefined;
            Cameras = new CameraXML();
        }

        public TCPPayload(
            AppConstants.SystemCommandsEnum s, 
            AppConstants.CustomPICBoardCommandsEnum customPIC, 
            AppConstants.PelcoDCommandsEnum pelcoD,
            AppConstants.TandbergViscaCommandsEnum tandbv,
            uint optional, uint cam)
        {
            PelcoDCommand = pelcoD;
            TandbergViscaCommand = tandbv;
            OptionalValue = optional;
            OptionalCameraValue = cam;
            Cameras = null;
        }

        public TCPPayload(
            AppConstants.SystemCommandsEnum s, 
            AppConstants.CustomPICBoardCommandsEnum customPIC,
            AppConstants.PelcoDCommandsEnum pelcoD,
            AppConstants.TandbergViscaCommandsEnum tandbv,
            uint optional, uint cam, CameraXML cameras)
        {
            CustomPICBoardCommand = customPIC;
            PelcoDCommand = pelcoD;
            TandbergViscaCommand = tandbv;
            OptionalValue = optional;
            OptionalCameraValue = cam;
            Cameras = cameras;
        }
    }

    public static class Helper
    {
        static XmlSerializer xs = new XmlSerializer(typeof(Common.TCPPayload));
        public static byte[] GetSerializedBytes(TCPPayload itemToSerialize)
        {

            byte[] itemsToReturn = null;
            using (MemoryStream memoryStream = new MemoryStream())
            {
                xs.Serialize(memoryStream, itemToSerialize);
                itemsToReturn = memoryStream.ToArray();
            }
            return itemsToReturn;
        }

        public static TCPPayload GetFromSerializedBytes(byte[] serialized)
        {
            TCPPayload itemToReturn = null;

            using (MemoryStream memoryStream = new MemoryStream(serialized))
            {
                object obj = xs.Deserialize(memoryStream);
                if (obj != null && obj is TCPPayload)
                    return (TCPPayload)obj;

            }

            return itemToReturn;
        }
    }
}
