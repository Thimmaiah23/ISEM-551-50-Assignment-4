﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CCTV.Common
{
    public class AppConstants
    {

        public enum CommandType
        {
            PelcoD,
            TandbergVisca,
            CustomPIC,
            VideoSwitch,
            StaticCamera,
            Unknown
        }

        public enum TandbergViscaCommandsEnum
        {
            Autofocus,
            ManualFocus,
            IrisReset,
            FocusStop,
            ZoomStop,
            MovementStop,
            Home,
            BackLightOn,
            BackLightOff,
            AWBOn,
            AWBOff,
            MoveLeft,   //
            MoveRight,  //
            MoveUp,     //
            MoveDown,   //
            ZoomTele,   //
            ZoomWide,   //
            IROn,         //
            IROff,         //
            FocusNear,  //
            FocusFar,   //
            IrisOpen,   //
            IrisClose,  //
            GetPreset,
            SetPreset,
            Undefined
        }
      
        public enum PelcoDCommandsEnum
        {
            Menu = 1,
            Stop,       //
            BeginPano,  //
            MoveLeft,   //
            MoveRight,  //
            MoveUp,     //
            MoveDown,   //
            ZoomTele,   //
            ZoomWide,   //
            Wiper,      //
            IR,         //
            Defog,      //
            FocusNear,  //
            FocusFar,   //
            IrisOpen,   //
            IrisClose,  //
            GetPreset,
            SetMovementSpeed,    //
            SetPreset,
            Undefined
        }

        public enum CustomPICBoardCommandsEnum
        {
            On = 1,
            Off,
            CamValue,
            Undefined
        }
        
        public enum SystemCommandsEnum
        {
            Ping = 1,
            CustomPICBoardCommand,
            PelcoDCommand,
            TandbergViscaCommand,
            GetConfig,
            SetConfig,
            GetUserList,
            GetConnectedUserList,
            AddUser,
            RemoveUser,
            DisconnectUser,
            SetPanoAtInterval,
            SetPanoAtIntervalAndSendByEmail,
            ShutDownPC,
            StartPC,
            Undefined
        }

        public enum VideoSizeEnum
        {
            Small,
            Medium,
            Large
        }

        public enum VideoCompressionEnum
        {
            Bad = 30,
            Medium = 60,
            Good = 75,
            Best = 90
        }

        public enum VideoCommandsEnum
        {
            Play,
            Stop,
            Pause
        }

        //lists device genres
        public enum DeviceType
        {
            VidoAT,
            TandbergWave,
            Honki,
            Honk,
            Honke,
            Honky

        }

        public enum RobotCommandsEnum
        {
            LEDOn,
            LEDOff,
            Connect,
            Disconnect,
            Wakeup,
            Sleep,
            Off,
            Voltage,
            CameraOn,
            CameraOff,
            Fwd,
            Rwd,
            Left,
            Right,
            Stop,
            IncreaseSpeed,
            DecreaseSpeed,
            FlashOn,
            FlashOff,
            SirenOn,
            SirenOff
        }
    }
}
